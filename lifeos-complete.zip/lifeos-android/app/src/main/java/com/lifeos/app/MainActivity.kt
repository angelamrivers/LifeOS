package com.lifeos.app

import android.os.Bundle
import android.speech.RecognizerIntent
import android.content.Intent
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.shape.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.*
import androidx.compose.ui.graphics.*
import androidx.compose.ui.text.font.*
import androidx.compose.ui.text.style.*
import androidx.compose.ui.unit.*
import com.lifeos.app.ui.theme.LifeOSTheme
import com.lifeos.app.viewmodel.TaskViewModel
import com.lifeos.app.data.*
import androidx.lifecycle.viewmodel.compose.viewModel
import java.util.*

class MainActivity : ComponentActivity() {

    private var voiceCallback: ((String) -> Unit)? = null

    private val speechLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == RESULT_OK) {
            val text = result.data
                ?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)
                ?.firstOrNull() ?: ""
            voiceCallback?.invoke(text)
        }
    }

    fun startVoiceInput(callback: (String) -> Unit) {
        voiceCallback = callback
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault())
            putExtra(RecognizerIntent.EXTRA_PROMPT, "What's on your mind?")
        }
        speechLauncher.launch(intent)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            LifeOSTheme {
                LifeOSApp(activity = this)
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LifeOSApp(activity: MainActivity, vm: TaskViewModel = viewModel()) {
    val tasks by vm.tasks.collectAsState()
    val isLoading by vm.isLoading.collectAsState()

    var selectedTab by remember { mutableStateOf(0) }
    var showBrainDump by remember { mutableStateOf(false) }
    var showChat by remember { mutableStateOf(false) }
    var showAddTask by remember { mutableStateOf(false) }
    var editingTask by remember { mutableStateOf<Task?>(null) }

    val tabs = listOf("Urgent","Health","Kids","Home","Money","Routines","Schedule")
    val tabCategories = listOf("urgent","health","kids","home","money","routines","schedule")

    LaunchedEffect(Unit) { vm.loadTasks() }

    Scaffold(
        containerColor = LifeOSColors.Surface,
        bottomBar = {
            LifeOSBottomBar(
                tabs = tabs,
                selected = selectedTab,
                onSelect = { selectedTab = it },
                onBrainDump = { showBrainDump = true },
                onChat = { showChat = true }
            )
        },
        floatingActionButton = {
            if (selectedTab < 5) {
                FloatingActionButton(
                    onClick = { showAddTask = true },
                    containerColor = LifeOSColors.Emerald,
                    shape = CircleShape
                ) {
                    Icon(Icons.Default.Add, contentDescription = "Add Task", tint = Color.White)
                }
            }
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
        ) {
            LifeOSHeader(tasks = tasks)

            when (selectedTab) {
                0, 1, 2, 3, 4 -> TaskPanel(
                    category = tabCategories[selectedTab],
                    tasks = tasks,
                    onToggle = { vm.toggleTask(it) },
                    onEdit = { editingTask = it },
                    onDelete = { vm.deleteTask(it.id) }
                )
                5 -> RoutinesPanel()
                6 -> SchedulePanel()
            }
        }
    }

    if (showBrainDump) {
        BrainDumpDialog(
            activity = activity,
            onDismiss = { showBrainDump = false },
            onConfirm = { tasks ->
                tasks.forEach { vm.addTask(it) }
                showBrainDump = false
            },
            vm = vm
        )
    }

    if (showChat) {
        ChatDialog(
            activity = activity,
            onDismiss = { showChat = false },
            vm = vm
        )
    }

    if (showAddTask) {
        AddEditTaskDialog(
            task = null,
            defaultCategory = tabCategories.getOrElse(selectedTab) { "urgent" },
            onDismiss = { showAddTask = false },
            onSave = { vm.addTask(it); showAddTask = false }
        )
    }

    editingTask?.let { task ->
        AddEditTaskDialog(
            task = task,
            defaultCategory = task.category,
            onDismiss = { editingTask = null },
            onSave = { vm.updateTask(it); editingTask = null }
        )
    }
}

@Composable
fun LifeOSHeader(tasks: List<Task>) {
    val total = tasks.size
    val done = tasks.count { it.done }
    val urgent = tasks.count { it.category == "urgent" && !it.done }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(LifeOSColors.Charcoal)
            .padding(20.dp, 16.dp, 20.dp, 20.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
                "✦ LifeOS",
                fontFamily = SerifFont,
                fontSize = 26.sp,
                fontWeight = FontWeight.SemiBold,
                color = LifeOSColors.Gold
            )
            Spacer(Modifier.weight(1f))
            Text(
                "Your Command Center",
                fontSize = 11.sp,
                color = Color.White.copy(alpha = 0.4f),
                letterSpacing = 1.sp
            )
        }

        Spacer(Modifier.height(16.dp))

        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            StatChip("$total", "Tasks", LifeOSColors.Sapphire)
            StatChip("$done", "Done", LifeOSColors.Gold)
            StatChip("${total - done}", "Active", LifeOSColors.Emerald)
            StatChip("$urgent", "Urgent", LifeOSColors.Ruby)
        }
    }
}

@Composable
fun StatChip(num: String, label: String, color: Color) {
    Column(
        modifier = Modifier
            .background(color.copy(alpha = 0.18f), RoundedCornerShape(10.dp))
            .padding(12.dp, 8.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(num, fontFamily = SerifFont, fontSize = 22.sp, fontWeight = FontWeight.SemiBold, color = color)
        Text(label, fontSize = 10.sp, color = Color.White.copy(alpha = 0.5f), letterSpacing = .5.sp)
    }
}

@Composable
fun LifeOSBottomBar(
    tabs: List<String>, selected: Int,
    onSelect: (Int) -> Unit, onBrainDump: () -> Unit, onChat: () -> Unit
) {
    val icons = listOf("⚡","♡","★","⌂","◈","⊙","☀")
    Column {
        Divider(color = LifeOSColors.Gold.copy(alpha = 0.15f))
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(LifeOSColors.Charcoal)
                .padding(vertical = 4.dp),
            horizontalArrangement = Arrangement.SpaceEvenly
        ) {
            tabs.take(5).forEachIndexed { i, tab ->
                BottomTab(icon = icons[i], label = tab, selected = selected == i) { onSelect(i) }
            }
            BottomTab(icon = "⊙", label = "Routines", selected = selected == 5) { onSelect(5) }
            BottomTab(icon = "☀", label = "Schedule", selected = selected == 6) { onSelect(6) }
        }
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(LifeOSColors.Dark)
                .padding(horizontal = 16.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Button(
                onClick = onBrainDump,
                modifier = Modifier.weight(1f),
                colors = ButtonDefaults.buttonColors(containerColor = LifeOSColors.Emerald),
                shape = RoundedCornerShape(10.dp)
            ) {
                Text("✦ Brain Dump", fontSize = 12.sp, fontWeight = FontWeight.Medium)
            }
            OutlinedButton(
                onClick = onChat,
                modifier = Modifier.weight(1f),
                border = BorderStroke(1.dp, LifeOSColors.Gold.copy(alpha = 0.4f)),
                shape = RoundedCornerShape(10.dp),
                colors = ButtonDefaults.outlinedButtonColors(contentColor = LifeOSColors.Gold)
            ) {
                Text("◈ Ask AI", fontSize = 12.sp)
            }
        }
    }
}

@Composable
fun BottomTab(icon: String, label: String, selected: Boolean, onClick: () -> Unit) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier
            .clickable { onClick() }
            .padding(horizontal = 6.dp, vertical = 6.dp)
    ) {
        Text(icon, fontSize = 16.sp, color = if (selected) LifeOSColors.Gold else Color.White.copy(.4f))
        Text(label, fontSize = 9.sp,
            color = if (selected) LifeOSColors.Gold else Color.White.copy(.35f),
            letterSpacing = .3.sp,
            maxLines = 1
        )
    }
}

@Composable
fun TaskPanel(
    category: String, tasks: List<Task>,
    onToggle: (Task) -> Unit, onEdit: (Task) -> Unit, onDelete: (Task) -> Unit
) {
    val filtered = tasks.filter { it.category == category }
    if (filtered.isEmpty()) {
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Text("No tasks yet — add one ✦", color = Color.Gray, fontSize = 14.sp)
        }
        return
    }
    LazyColumn(
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        items(filtered, key = { it.id }) { task ->
            TaskCard(task = task, onToggle = onToggle, onEdit = onEdit, onDelete = onDelete)
        }
    }
}

@Composable
fun TaskCard(task: Task, onToggle: (Task) -> Unit, onEdit: (Task) -> Unit, onDelete: (Task) -> Unit) {
    val badgeColor = badgeColors(task.badge)

    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        shape = RoundedCornerShape(12.dp),
        border = BorderStroke(0.5.dp, LifeOSColors.Gold.copy(alpha = 0.15f)),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Row(
            modifier = Modifier.padding(14.dp, 12.dp),
            verticalAlignment = Alignment.Top
        ) {
            Box(
                modifier = Modifier
                    .size(22.dp)
                    .clip(RoundedCornerShape(6.dp))
                    .background(if (task.done) LifeOSColors.Emerald else Color.Transparent)
                    .border(1.5.dp, if (task.done) LifeOSColors.Emerald else LifeOSColors.Gold.copy(.3f), RoundedCornerShape(6.dp))
                    .clickable { onToggle(task) },
                contentAlignment = Alignment.Center
            ) {
                if (task.done) Text("✓", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
            }

            Spacer(Modifier.width(12.dp))

            Column(Modifier.weight(1f)) {
                Text(
                    task.text,
                    fontSize = 14.sp,
                    color = if (task.done) Color.Gray else LifeOSColors.Text,
                    textDecoration = if (task.done) TextDecoration.LineThrough else TextDecoration.None,
                    lineHeight = 20.sp
                )
                Spacer(Modifier.height(6.dp))
                Surface(
                    color = badgeColor.first.copy(alpha = 0.12f),
                    shape = RoundedCornerShape(20.dp)
                ) {
                    Text(
                        task.badge,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 3.dp),
                        fontSize = 10.sp, fontWeight = FontWeight.Medium,
                        color = badgeColor.first, letterSpacing = .3.sp
                    )
                }
            }

            Column {
                IconButton(onClick = { onEdit(task) }, modifier = Modifier.size(30.dp)) {
                    Icon(Icons.Default.Edit, contentDescription = "Edit",
                        tint = LifeOSColors.Sapphire.copy(.6f), modifier = Modifier.size(16.dp))
                }
                IconButton(onClick = { onDelete(task) }, modifier = Modifier.size(30.dp)) {
                    Icon(Icons.Default.Delete, contentDescription = "Delete",
                        tint = LifeOSColors.Ruby.copy(.6f), modifier = Modifier.size(16.dp))
                }
            }
        }
    }
}

@Composable
fun AddEditTaskDialog(
    task: Task?,
    defaultCategory: String,
    onDismiss: () -> Unit,
    onSave: (Task) -> Unit
) {
    var text by remember { mutableStateOf(task?.text ?: "") }
    var category by remember { mutableStateOf(task?.category ?: defaultCategory) }
    var badge by remember { mutableStateOf(task?.badge ?: "Soon") }

    val categories = listOf("urgent","health","kids","home","money")
    val badges = listOf("Today","ASAP","This week","Soon","Ongoing","Daily","Plan","Research","Project","Weekly","Bi-weekly","Priority","Save","Now","Explore")

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Color.White,
        shape = RoundedCornerShape(16.dp),
        title = { Text(if (task == null) "Add Task" else "Edit Task", fontFamily = SerifFont, fontSize = 20.sp) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
                OutlinedTextField(
                    value = text, onValueChange = { text = it },
                    label = { Text("Task description") },
                    modifier = Modifier.fillMaxWidth(),
                    minLines = 2,
                    shape = RoundedCornerShape(10.dp)
                )
                DropdownField("Category", categories, category) { category = it }
                DropdownField("Badge / Priority", badges, badge) { badge = it }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (text.isNotBlank()) {
                        onSave(Task(id = task?.id ?: UUID.randomUUID().toString(), text = text, category = category, badge = badge, done = task?.done ?: false))
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = LifeOSColors.Emerald),
                shape = RoundedCornerShape(10.dp)
            ) { Text("Save ✦") }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel", color = Color.Gray) }
        }
    )
}

@Composable
fun DropdownField(label: String, options: List<String>, selected: String, onSelect: (String) -> Unit) {
    var expanded by remember { mutableStateOf(false) }
    Box {
        OutlinedTextField(
            value = selected, onValueChange = {},
            label = { Text(label) },
            modifier = Modifier.fillMaxWidth().clickable { expanded = true },
            readOnly = true,
            trailingIcon = { Icon(Icons.Default.ArrowDropDown, null) },
            shape = RoundedCornerShape(10.dp)
        )
        DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
            options.forEach { opt ->
                DropdownMenuItem(text = { Text(opt, fontSize = 13.sp) }, onClick = { onSelect(opt); expanded = false })
            }
        }
    }
}

@Composable
fun RoutinesPanel() {
    LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        item { RoutineCard("☀ Morning Routine", listOf("16 oz water" to "On waking", "ACV + lemon shot" to "Before breakfast", "Creatine + supplements" to "With breakfast", "Herbal tea tracker" to "Morning", "Treadmill incline walk" to "8,000+ steps", "Read 10 pages" to "Any time AM")) }
        item { RoutineCard("☽ Evening Routine", listOf("Self-care task (75 challenge)" to "Each evening", "Family reading time" to "30 min", "Track food & water" to "64 oz total", "Herbal tea night blend" to "Evening", "Pilates or weights" to "Home workout")) }
        item { ChallengeCard() }
        item { RoutineCard("◈ Weekly Rhythm", listOf("Job applications" to "2 hrs/day", "Dean instruments" to "Daily", "Kids outings" to "2×/week", "Date night w/ Oskar" to "Bi-weekly", "Cleaning blocks" to "1 hr/daily", "Credit repair tasks" to "Weekly")) }
    }
}

@Composable
fun RoutineCard(title: String, rows: List<Pair<String, String>>) {
    Card(
        colors = CardDefaults.cardColors(containerColor = Color.White),
        shape = RoundedCornerShape(12.dp),
        border = BorderStroke(0.5.dp, LifeOSColors.Gold.copy(.15f)),
        elevation = CardDefaults.cardElevation(2.dp)
    ) {
        Column(Modifier.padding(18.dp)) {
            Text(title, fontFamily = SerifFont, fontSize = 18.sp, fontWeight = FontWeight.SemiBold, color = LifeOSColors.Charcoal)
            Spacer(Modifier.height(12.dp))
            rows.forEach { (label, value) ->
                Row(Modifier.fillMaxWidth().padding(vertical = 6.dp)) {
                    Text(label, fontSize = 13.sp, color = LifeOSColors.TextMuted, modifier = Modifier.weight(1f))
                    Text(value, fontSize = 12.sp, fontWeight = FontWeight.Medium, color = LifeOSColors.Text)
                }
                Divider(color = Color.Black.copy(0.04f))
            }
        }
    }
}

@Composable
fun ChallengeCard() {
    val items = listOf("Read 10 pages","64 oz water","1 self-care task","No alcohol","Healthy eating 80%","ACV + lemon shot")
    val done = remember { mutableStateListOf(*Array(6) { false }) }
    val pct = (done.count { it } * 100f / 6).toInt()

    Card(
        colors = CardDefaults.cardColors(containerColor = Color.White),
        shape = RoundedCornerShape(12.dp),
        border = BorderStroke(2.dp, LifeOSColors.Gold.copy(.5f)),
        elevation = CardDefaults.cardElevation(2.dp)
    ) {
        Column(Modifier.padding(18.dp)) {
            Text("✦ 75 Challenge Tracker", fontFamily = SerifFont, fontSize = 18.sp, fontWeight = FontWeight.SemiBold, color = LifeOSColors.Charcoal)
            Spacer(Modifier.height(12.dp))
            items.forEachIndexed { i, label ->
                Row(
                    Modifier.fillMaxWidth().clickable { done[i] = !done[i] }.padding(vertical = 7.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(if (done[i]) "●" else "○", fontSize = 16.sp, color = if (done[i]) LifeOSColors.Emerald else Color.Gray)
                    Spacer(Modifier.width(12.dp))
                    Text(label, fontSize = 13.sp, color = LifeOSColors.TextMuted)
                }
                Divider(color = Color.Black.copy(.04f))
            }
            Spacer(Modifier.height(12.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                LinearProgressIndicator(
                    progress = pct / 100f,
                    modifier = Modifier.weight(1f).height(6.dp).clip(RoundedCornerShape(3.dp)),
                    color = LifeOSColors.Emerald, trackColor = Color(0xFFE8F5F0)
                )
                Spacer(Modifier.width(12.dp))
                Text("$pct%", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = LifeOSColors.Emerald)
            }
        }
    }
}

@Composable
fun SchedulePanel() {
    val blocks = listOf(
        Triple("7:00 – 8:00 AM", "Wake up, breakfast & morning routine", LifeOSColors.Emerald),
        Triple("8:00 – 9:00 AM", "Educational focus — reading, French, math (all kids)", LifeOSColors.Sapphire),
        Triple("9:00 – 10:00 AM", "Dean: 15m horn + 30m viola · Matt & Ava: structured game", LifeOSColors.Gold),
        Triple("10:00 – 11:00 AM", "Active outdoor time — basketball, bikes, yard play", LifeOSColors.Emerald),
        Triple("11:00 AM – 1:00 PM", "Your treadmill walk + job applications · Kids: independent play", Color.Gray),
        Triple("1:00 – 2:00 PM", "Lunch + 30 min family reading time", LifeOSColors.Sapphire),
        Triple("2:00 – 4:00 PM", "Job applications (Hour 2) · Kids: creative or limited Roblox", LifeOSColors.Gold),
        Triple("4:00 – 5:00 PM", "House cleaning block — rotate rooms daily", Color.Gray),
        Triple("5:00 – 7:00 PM", "Dinner prep, eat together, kids' evening wind-down", LifeOSColors.Emerald),
        Triple("7:00 – 9:00 PM", "Pilates/weights · self-care · reading · herbal tea tracking", LifeOSColors.Sapphire)
    )
    LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        items(blocks) { (time, desc, color) ->
            Card(
                colors = CardDefaults.cardColors(containerColor = Color.White),
                shape = RoundedCornerShape(0.dp, 12.dp, 12.dp, 0.dp),
                modifier = Modifier.fillMaxWidth(),
                border = BorderStroke(0.5.dp, LifeOSColors.Gold.copy(.12f))
            ) {
                Row {
                    Box(Modifier.width(4.dp).height(72.dp).background(color))
                    Column(Modifier.padding(14.dp, 10.dp)) {
                        Text(time, fontSize = 11.sp, fontWeight = FontWeight.SemiBold, color = Color.Gray, letterSpacing = .5.sp)
                        Spacer(Modifier.height(4.dp))
                        Text(desc, fontSize = 13.5.sp, color = LifeOSColors.Text, lineHeight = 19.sp)
                    }
                }
            }
        }
    }
}

// ── Brain Dump Dialog ─────────────────────────────────
@Composable
fun BrainDumpDialog(
    activity: MainActivity,
    onDismiss: () -> Unit,
    onConfirm: (List<Task>) -> Unit,
    vm: TaskViewModel
) {
    var text by remember { mutableStateOf("") }
    var isAnalyzing by remember { mutableStateOf(false) }
    var results by remember { mutableStateOf<BrainDumpResult?>(null) }
    val scope = rememberCoroutineScope()

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Color.White,
        shape = RoundedCornerShape(16.dp),
        title = { Text("✦ Brain Dump", fontFamily = SerifFont, fontSize = 22.sp) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                if (results == null) {
                    Text("Pour it all out. Your AI will sort it into tasks.", fontSize = 13.sp, color = Color.Gray)
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        OutlinedButton(
                            onClick = {
                                activity.startVoiceInput { transcript ->
                                    text = if (text.isBlank()) transcript else "$text $transcript"
                                }
                            },
                            border = BorderStroke(1.dp, LifeOSColors.Gold.copy(.4f)),
                            shape = CircleShape,
                            contentPadding = PaddingValues(12.dp)
                        ) { Text("🎙", fontSize = 18.sp) }
                        Text("Tap mic to speak", fontSize = 12.sp, color = Color.Gray)
                    }
                    OutlinedTextField(
                        value = text, onValueChange = { text = it },
                        modifier = Modifier.fillMaxWidth().height(120.dp),
                        placeholder = { Text("e.g. Need to call dentist, pay bill, start working out...", fontSize = 13.sp) },
                        shape = RoundedCornerShape(10.dp)
                    )
                    if (isAnalyzing) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                            CircularProgressIndicator(Modifier.size(20.dp), color = LifeOSColors.Emerald, strokeWidth = 2.dp)
                            Text("Analyzing your thoughts...", fontSize = 13.sp, color = Color.Gray)
                        }
                    }
                } else {
                    Text(results!!.summary, fontSize = 13.sp, color = LifeOSColors.Text, fontStyle = androidx.compose.ui.text.font.FontStyle.Italic,
                        modifier = Modifier.background(Color(0xFFE8F5F0), RoundedCornerShape(8.dp)).padding(12.dp))
                    Text("${results!!.tasks.size} tasks found — review and confirm:", fontSize = 12.sp, color = Color.Gray)
                    results!!.tasks.forEach { task ->
                        Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                            Text("•", color = LifeOSColors.Emerald, fontSize = 16.sp)
                            Spacer(Modifier.width(8.dp))
                            Text(task.text, fontSize = 13.sp, modifier = Modifier.weight(1f))
                        }
                    }
                }
            }
        },
        confirmButton = {
            if (results == null) {
                Button(
                    onClick = {
                        if (text.isNotBlank()) {
                            isAnalyzing = true
                            scope.launch {
                                val r = vm.analyzeBrainDump(text)
                                results = r
                                isAnalyzing = false
                            }
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = LifeOSColors.Emerald),
                    shape = RoundedCornerShape(10.dp),
                    enabled = !isAnalyzing
                ) { Text("Analyze & Sort ✦") }
            } else {
                Button(
                    onClick = { onConfirm(results!!.tasks) },
                    colors = ButtonDefaults.buttonColors(containerColor = LifeOSColors.Emerald),
                    shape = RoundedCornerShape(10.dp)
                ) { Text("Add All Tasks ✦") }
            }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel", color = Color.Gray) } }
    )
}

// ── Chat Dialog ───────────────────────────────────────
@Composable
fun ChatDialog(activity: MainActivity, onDismiss: () -> Unit, vm: TaskViewModel) {
    var input by remember { mutableStateOf("") }
    val messages by vm.chatMessages.collectAsState()
    val isThinking by vm.isChatLoading.collectAsState()
    val scope = rememberCoroutineScope()
    val listState = rememberLazyListState()

    LaunchedEffect(messages.size) {
        if (messages.isNotEmpty()) listState.animateScrollToItem(messages.size - 1)
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Color.White,
        shape = RoundedCornerShape(16.dp),
        modifier = Modifier.fillMaxHeight(0.85f),
        title = { Text("◈ Ask Your AI", fontFamily = SerifFont, fontSize = 22.sp) },
        text = {
            Column(Modifier.fillMaxHeight()) {
                LazyColumn(state = listState, modifier = Modifier.weight(1f).fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    items(messages) { msg ->
                        val isUser = msg.role == "user"
                        Box(Modifier.fillMaxWidth(), contentAlignment = if (isUser) Alignment.CenterEnd else Alignment.CenterStart) {
                            Surface(
                                color = if (isUser) LifeOSColors.Emerald else Color(0xFFE8EEF8),
                                shape = RoundedCornerShape(12.dp, 12.dp, if (isUser) 2.dp else 12.dp, if (isUser) 12.dp else 2.dp),
                                modifier = Modifier.widthIn(max = 280.dp)
                            ) {
                                Text(msg.content, modifier = Modifier.padding(12.dp, 10.dp),
                                    fontSize = 13.5.sp, color = if (isUser) Color.White else LifeOSColors.Text, lineHeight = 20.sp)
                            }
                        }
                    }
                    if (isThinking) {
                        item {
                            Row(Modifier.padding(4.dp), horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                                CircularProgressIndicator(Modifier.size(14.dp), color = LifeOSColors.Emerald, strokeWidth = 2.dp)
                                Text("Thinking...", fontSize = 12.sp, color = Color.Gray)
                            }
                        }
                    }
                }
                Spacer(Modifier.height(10.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                    OutlinedButton(
                        onClick = { activity.startVoiceInput { transcript -> input = transcript } },
                        border = BorderStroke(1.dp, LifeOSColors.Gold.copy(.4f)),
                        shape = CircleShape,
                        contentPadding = PaddingValues(10.dp),
                        modifier = Modifier.size(40.dp)
                    ) { Text("🎙", fontSize = 16.sp) }
                    OutlinedTextField(
                        value = input, onValueChange = { input = it },
                        modifier = Modifier.weight(1f),
                        placeholder = { Text("Ask anything...", fontSize = 13.sp) },
                        shape = RoundedCornerShape(10.dp),
                        singleLine = true
                    )
                    Button(
                        onClick = {
                            if (input.isNotBlank()) {
                                scope.launch { vm.sendChat(input); input = "" }
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = LifeOSColors.Emerald),
                        shape = RoundedCornerShape(10.dp),
                        contentPadding = PaddingValues(12.dp, 10.dp)
                    ) { Text("Send", fontSize = 12.sp) }
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Close", color = Color.Gray) } }
    )
}

// ── Helpers ───────────────────────────────────────────
fun badgeColors(badge: String): Pair<Color, Color> = when (badge) {
    "Today","ASAP","Now","Priority" -> Pair(LifeOSColors.Ruby, Color(0xFFFDF0F0))
    "This week","Soon","Save for"   -> Pair(LifeOSColors.Gold, Color(0xFFFDF8E8))
    "Ongoing","Daily","Weekly","Bi-weekly" -> Pair(LifeOSColors.Sapphire, Color(0xFFE8EEF8))
    else -> Pair(LifeOSColors.Emerald, Color(0xFFE8F5F0))
}

val SerifFont = FontFamily.Default // Replace with actual Cormorant Garamond if bundled
