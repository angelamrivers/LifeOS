package com.lifeos.app.network

import com.lifeos.app.data.*
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.*

interface LifeOSApi {
    @GET("api/tasks")
    suspend fun getTasks(): List<Task>

    @POST("api/tasks")
    suspend fun addTask(@Body task: Task): Task

    @PUT("api/tasks/{id}")
    suspend fun updateTask(@Path("id") id: String, @Body update: TaskUpdateRequest): Task

    @DELETE("api/tasks/{id}")
    suspend fun deleteTask(@Path("id") id: String)

    @POST("api/braindump")
    suspend fun brainDump(@Body req: BrainDumpRequest): BrainDumpResult

    @POST("api/chat")
    suspend fun chat(@Body req: ChatRequest): ChatResponse
}

object ApiClient {
    // Replace with your deployed Render URL
    private const val BASE_URL = "https://your-app-name.onrender.com/"

    val api: LifeOSApi by lazy {
        Retrofit.Builder()
            .baseUrl(BASE_URL)
            .addConverterFactory(GsonConverterFactory.create())
            .build()
            .create(LifeOSApi::class.java)
    }
}
