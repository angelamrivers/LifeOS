package com.lifeos.app.ui.theme

import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

object LifeOSColors {
    val Emerald   = Color(0xFF1A5C45)
    val EmeraldLight = Color(0xFF2D8A6A)
    val Sapphire  = Color(0xFF1A3A6B)
    val SapphireLight = Color(0xFF2A5298)
    val Gold      = Color(0xFFC9A84C)
    val GoldLight = Color(0xFFD4A017)
    val Ruby      = Color(0xFF8B1A1A)
    val Charcoal  = Color(0xFF1C1C2E)
    val Dark      = Color(0xFF12121E)
    val Surface   = Color(0xFFF8F7F4)
    val Text      = Color(0xFF1C1C2E)
    val TextMuted = Color(0xFF5A5A7A)
    val Border    = Color(0x2EC9A84C)
}

private val JewelColorScheme = lightColorScheme(
    primary        = LifeOSColors.Emerald,
    onPrimary      = Color.White,
    secondary      = LifeOSColors.Sapphire,
    onSecondary    = Color.White,
    tertiary       = LifeOSColors.Gold,
    onTertiary     = Color.White,
    background     = LifeOSColors.Surface,
    onBackground   = LifeOSColors.Text,
    surface        = Color.White,
    onSurface      = LifeOSColors.Text,
    surfaceVariant = Color(0xFFF2F0EA),
    outline        = LifeOSColors.Border
)

@Composable
fun LifeOSTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = JewelColorScheme,
        content = content
    )
}
