package com.lifeos.app.data

import com.google.gson.annotations.SerializedName

data class Task(
    val id: String,
    val text: String,
    val category: String,
    val badge: String,
    val done: Boolean = false,
    val created: String = ""
)

data class BrainDumpResult(
    val summary: String,
    val tasks: List<Task>
)

data class ChatMessage(
    val role: String,
    val content: String
)

data class BrainDumpRequest(val text: String)
data class ChatRequest(val message: String, val history: List<ChatMessage>)
data class ChatResponse(val reply: String)
data class TaskUpdateRequest(
    val text: String? = null,
    val category: String? = null,
    val badge: String? = null,
    val done: Boolean? = null
)
