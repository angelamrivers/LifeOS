package com.lifeos.app.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.lifeos.app.data.*
import com.lifeos.app.network.ApiClient
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

class TaskViewModel : ViewModel() {

    private val _tasks = MutableStateFlow<List<Task>>(emptyList())
    val tasks: StateFlow<List<Task>> = _tasks

    private val _isLoading = MutableStateFlow(false)
    val isLoading: StateFlow<Boolean> = _isLoading

    private val _chatMessages = MutableStateFlow<List<ChatMessage>>(listOf(
        ChatMessage("assistant", "Hello! I know everything about your LifeOS. Ask me anything — I can help you prioritize, plan, or just think out loud. ✦")
    ))
    val chatMessages: StateFlow<List<ChatMessage>> = _chatMessages

    private val _isChatLoading = MutableStateFlow(false)
    val isChatLoading: StateFlow<Boolean> = _isChatLoading

    fun loadTasks() {
        viewModelScope.launch {
            _isLoading.value = true
            try {
                _tasks.value = ApiClient.api.getTasks()
            } catch (e: Exception) {
                // Fallback to empty list on network error
            } finally {
                _isLoading.value = false
            }
        }
    }

    fun addTask(task: Task) {
        viewModelScope.launch {
            try {
                val created = ApiClient.api.addTask(task)
                _tasks.value = _tasks.value + created
            } catch (e: Exception) {
                // Optimistic add for offline
                _tasks.value = _tasks.value + task
            }
        }
    }

    fun updateTask(task: Task) {
        viewModelScope.launch {
            try {
                val updated = ApiClient.api.updateTask(task.id, TaskUpdateRequest(
                    text = task.text, category = task.category,
                    badge = task.badge, done = task.done
                ))
                _tasks.value = _tasks.value.map { if (it.id == updated.id) updated else it }
            } catch (e: Exception) {
                _tasks.value = _tasks.value.map { if (it.id == task.id) task else it }
            }
        }
    }

    fun toggleTask(task: Task) {
        updateTask(task.copy(done = !task.done))
    }

    fun deleteTask(id: String) {
        viewModelScope.launch {
            try {
                ApiClient.api.deleteTask(id)
            } catch (e: Exception) {}
            _tasks.value = _tasks.value.filter { it.id != id }
        }
    }

    suspend fun analyzeBrainDump(text: String): BrainDumpResult? {
        return try {
            ApiClient.api.brainDump(BrainDumpRequest(text))
        } catch (e: Exception) {
            null
        }
    }

    fun sendChat(message: String) {
        viewModelScope.launch {
            _chatMessages.value = _chatMessages.value + ChatMessage("user", message)
            _isChatLoading.value = true
            try {
                val history = _chatMessages.value.takeLast(8)
                val response = ApiClient.api.chat(ChatRequest(message, history))
                _chatMessages.value = _chatMessages.value + ChatMessage("assistant", response.reply)
            } catch (e: Exception) {
                _chatMessages.value = _chatMessages.value + ChatMessage("assistant", "Sorry, I had trouble connecting. Please check your internet and try again.")
            } finally {
                _isChatLoading.value = false
            }
        }
    }
}
