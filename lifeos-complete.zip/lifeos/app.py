from flask import Flask, request, jsonify, render_template
from flask_cors import CORS
import json, os, uuid, anthropic
from datetime import datetime

app = Flask(__name__)
CORS(app)

DATA_FILE = "data/tasks.json"
ANTHROPIC_API_KEY = os.environ.get("ANTHROPIC_API_KEY", "")

CATEGORIES = ["urgent", "health", "kids", "home", "money", "routines"]

BADGE_TYPES = ["Today", "ASAP", "This week", "Soon", "Ongoing", "Daily",
               "Plan", "Research", "Project", "Weekly", "Bi-weekly",
               "Priority", "Save", "Now", "Explore"]

def load_data():
    if not os.path.exists(DATA_FILE):
        return get_default_data()
    with open(DATA_FILE, "r") as f:
        return json.load(f)

def save_data(data):
    os.makedirs("data", exist_ok=True)
    with open(DATA_FILE, "w") as f:
        json.dump(data, f, indent=2)

def get_default_data():
    return {
        "tasks": [
            {"id": str(uuid.uuid4()), "text": "Complete and submit food aid renewal paperwork", "category": "urgent", "badge": "Today", "done": False, "created": datetime.now().isoformat()},
            {"id": str(uuid.uuid4()), "text": "Complete and send 2 enrollment forms for Robotics STEM Camp", "category": "urgent", "badge": "ASAP", "done": False, "created": datetime.now().isoformat()},
            {"id": str(uuid.uuid4()), "text": "Return Matthew's Roblox library software", "category": "urgent", "badge": "ASAP", "done": False, "created": datetime.now().isoformat()},
            {"id": str(uuid.uuid4()), "text": "Donate, wash, and organize large mountain of clothes (bedroom + basement)", "category": "urgent", "badge": "This week", "done": False, "created": datetime.now().isoformat()},
            {"id": str(uuid.uuid4()), "text": "Call to reschedule kids' annual physical appointments", "category": "urgent", "badge": "This week", "done": False, "created": datetime.now().isoformat()},
            {"id": str(uuid.uuid4()), "text": "Reschedule own doctor appointment (ferritin & omega results)", "category": "urgent", "badge": "This week", "done": False, "created": datetime.now().isoformat()},
            {"id": str(uuid.uuid4()), "text": "Schedule dentist appointments for kids, Oskar, and yourself", "category": "urgent", "badge": "This week", "done": False, "created": datetime.now().isoformat()},
            {"id": str(uuid.uuid4()), "text": "Walk treadmill on incline daily — minimum 8,000 steps", "category": "health", "badge": "Daily", "done": False, "created": datetime.now().isoformat()},
            {"id": str(uuid.uuid4()), "text": "Lose 15 lbs — tone back, shoulders, arms; build glutes", "category": "health", "badge": "Ongoing", "done": False, "created": datetime.now().isoformat()},
            {"id": str(uuid.uuid4()), "text": "Start beginner home Pilates routine", "category": "health", "badge": "Ongoing", "done": False, "created": datetime.now().isoformat()},
            {"id": str(uuid.uuid4()), "text": "Begin home weight lifting — focus on glutes and upper body", "category": "health", "badge": "Ongoing", "done": False, "created": datetime.now().isoformat()},
            {"id": str(uuid.uuid4()), "text": "Incorporate creatine supplementation", "category": "health", "badge": "Daily", "done": False, "created": datetime.now().isoformat()},
            {"id": str(uuid.uuid4()), "text": "Read 10 pages daily (75 challenge)", "category": "health", "badge": "Daily", "done": False, "created": datetime.now().isoformat()},
            {"id": str(uuid.uuid4()), "text": "Drink 64 oz of water daily (75 challenge)", "category": "health", "badge": "Daily", "done": False, "created": datetime.now().isoformat()},
            {"id": str(uuid.uuid4()), "text": "Complete one self-care task each evening (75 challenge)", "category": "health", "badge": "Daily", "done": False, "created": datetime.now().isoformat()},
            {"id": str(uuid.uuid4()), "text": "No alcohol (75 challenge)", "category": "health", "badge": "Daily", "done": False, "created": datetime.now().isoformat()},
            {"id": str(uuid.uuid4()), "text": "Eat healthy 80% of the time (75 challenge)", "category": "health", "badge": "Daily", "done": False, "created": datetime.now().isoformat()},
            {"id": str(uuid.uuid4()), "text": "Take ACV + lemon shot before largest meal (75 challenge)", "category": "health", "badge": "Daily", "done": False, "created": datetime.now().isoformat()},
            {"id": str(uuid.uuid4()), "text": "Create printable tracker for the 75 challenge", "category": "health", "badge": "Soon", "done": False, "created": datetime.now().isoformat()},
            {"id": str(uuid.uuid4()), "text": "Do 7-day parasite cleanse: oil of oregano, tamarind, papaya seeds", "category": "health", "badge": "Plan", "done": False, "created": datetime.now().isoformat()},
            {"id": str(uuid.uuid4()), "text": "Start daily herbal tea, supplements, and healthy drinks tracker", "category": "health", "badge": "Ongoing", "done": False, "created": datetime.now().isoformat()},
            {"id": str(uuid.uuid4()), "text": "Research low iron levels: natural increase vs. iron infusions", "category": "health", "badge": "Soon", "done": False, "created": datetime.now().isoformat()},
            {"id": str(uuid.uuid4()), "text": "Reschedule annual physicals for Dean (10), Matthew (7), and Ava (5)", "category": "kids", "badge": "ASAP", "done": False, "created": datetime.now().isoformat()},
            {"id": str(uuid.uuid4()), "text": "Schedule dentist appointments for all three kids", "category": "kids", "badge": "Soon", "done": False, "created": datetime.now().isoformat()},
            {"id": str(uuid.uuid4()), "text": "Send completed enrollment forms for Robotics STEM Camp", "category": "kids", "badge": "ASAP", "done": False, "created": datetime.now().isoformat()},
            {"id": str(uuid.uuid4()), "text": "Plan and save budget for back-to-school clothes (Dean, Matthew, Ava)", "category": "kids", "badge": "Save", "done": False, "created": datetime.now().isoformat()},
            {"id": str(uuid.uuid4()), "text": "Implement structured daily summer schedule to limit screen/gaming time", "category": "kids", "badge": "This week", "done": False, "created": datetime.now().isoformat()},
            {"id": str(uuid.uuid4()), "text": "Dean's music: 15 min French horn + 30 min viola daily", "category": "kids", "badge": "Daily", "done": False, "created": datetime.now().isoformat()},
            {"id": str(uuid.uuid4()), "text": "Plan educational + active things for Matthew and Ava (basketball, etc.)", "category": "kids", "badge": "Plan", "done": False, "created": datetime.now().isoformat()},
            {"id": str(uuid.uuid4()), "text": "Compile summer reading lists for all 3 kids, Oskar, and myself", "category": "kids", "badge": "Soon", "done": False, "created": datetime.now().isoformat()},
            {"id": str(uuid.uuid4()), "text": "30 minutes of daily family reading time", "category": "kids", "badge": "Daily", "done": False, "created": datetime.now().isoformat()},
            {"id": str(uuid.uuid4()), "text": "Help Dean and Matthew create gaming videos and monetize Roblox items", "category": "kids", "badge": "Project", "done": False, "created": datetime.now().isoformat()},
            {"id": str(uuid.uuid4()), "text": "Plan 2x/week outings to public places with the kids", "category": "kids", "badge": "Weekly", "done": False, "created": datetime.now().isoformat()},
            {"id": str(uuid.uuid4()), "text": "Calculate savings required for 2 small family summer vacations", "category": "kids", "badge": "Plan", "done": False, "created": datetime.now().isoformat()},
            {"id": str(uuid.uuid4()), "text": "Plan 1–2 water park day trips for the family", "category": "kids", "badge": "Plan", "done": False, "created": datetime.now().isoformat()},
            {"id": str(uuid.uuid4()), "text": "Plan bi-weekly date nights with Oskar", "category": "kids", "badge": "Bi-weekly", "done": False, "created": datetime.now().isoformat()},
            {"id": str(uuid.uuid4()), "text": "Donate, wash, and organize clothing mountain (bedroom + laundry room)", "category": "home", "badge": "ASAP", "done": False, "created": datetime.now().isoformat()},
            {"id": str(uuid.uuid4()), "text": "Clean master bedroom and boys' upstairs closet", "category": "home", "badge": "This week", "done": False, "created": datetime.now().isoformat()},
            {"id": str(uuid.uuid4()), "text": "Deep clean the pantry", "category": "home", "badge": "Soon", "done": False, "created": datetime.now().isoformat()},
            {"id": str(uuid.uuid4()), "text": "Organize the office file cabinet", "category": "home", "badge": "Soon", "done": False, "created": datetime.now().isoformat()},
            {"id": str(uuid.uuid4()), "text": "Create fridge/freezer inventory board (Fruit, Vegetables, Proteins)", "category": "home", "badge": "Soon", "done": False, "created": datetime.now().isoformat()},
            {"id": str(uuid.uuid4()), "text": "Organize family recipes and build a monthly grocery list", "category": "home", "badge": "Soon", "done": False, "created": datetime.now().isoformat()},
            {"id": str(uuid.uuid4()), "text": "Create master household list (toiletries, supplements, cleaning supplies)", "category": "home", "badge": "Soon", "done": False, "created": datetime.now().isoformat()},
            {"id": str(uuid.uuid4()), "text": "Build monthly household and car maintenance schedule", "category": "home", "badge": "Soon", "done": False, "created": datetime.now().isoformat()},
            {"id": str(uuid.uuid4()), "text": "Order new linens for everyone in the house", "category": "home", "badge": "Soon", "done": False, "created": datetime.now().isoformat()},
            {"id": str(uuid.uuid4()), "text": "Fix large hole on outside of front indoor door", "category": "home", "badge": "Priority", "done": False, "created": datetime.now().isoformat()},
            {"id": str(uuid.uuid4()), "text": "Bathroom overhaul: ventilation system, bathtub, shower setup", "category": "home", "badge": "Save for", "done": False, "created": datetime.now().isoformat()},
            {"id": str(uuid.uuid4()), "text": "Purchase and install a new dryer", "category": "home", "badge": "Priority", "done": False, "created": datetime.now().isoformat()},
            {"id": str(uuid.uuid4()), "text": "Fix AC in both vehicles", "category": "home", "badge": "Soon", "done": False, "created": datetime.now().isoformat()},
            {"id": str(uuid.uuid4()), "text": "Spend minimum 2 hrs/day applying to jobs", "category": "money", "badge": "Daily", "done": False, "created": datetime.now().isoformat()},
            {"id": str(uuid.uuid4()), "text": "Research unconventional jobs matching psychology BA + 50% MBA", "category": "money", "badge": "Research", "done": False, "created": datetime.now().isoformat()},
            {"id": str(uuid.uuid4()), "text": "Further develop LinkedIn profile and optimize keywords", "category": "money", "badge": "Soon", "done": False, "created": datetime.now().isoformat()},
            {"id": str(uuid.uuid4()), "text": "Determine precise budget & cost-saving measures to restore two-parent salary", "category": "money", "badge": "Now", "done": False, "created": datetime.now().isoformat()},
            {"id": str(uuid.uuid4()), "text": "Map strategic path to achieve $80k+ annually (job, content, or business)", "category": "money", "badge": "Plan", "done": False, "created": datetime.now().isoformat()},
            {"id": str(uuid.uuid4()), "text": "Check process and deadlines to restart at Univ. of Maine – Presque Isle (fall)", "category": "money", "badge": "Soon", "done": False, "created": datetime.now().isoformat()},
            {"id": str(uuid.uuid4()), "text": "Work on comprehensive credit repair for both you and Oskar", "category": "money", "badge": "Ongoing", "done": False, "created": datetime.now().isoformat()},
            {"id": str(uuid.uuid4()), "text": "Research and formulate a long-term wealth building plan", "category": "money", "badge": "Plan", "done": False, "created": datetime.now().isoformat()},
            {"id": str(uuid.uuid4()), "text": "Budget and secure funding for urgent repairs (door, dryer, car ACs)", "category": "money", "badge": "Now", "done": False, "created": datetime.now().isoformat()},
            {"id": str(uuid.uuid4()), "text": "Evaluate nonprofit vs. LLC route for Oskar's youth soccer organization", "category": "money", "badge": "Research", "done": False, "created": datetime.now().isoformat()},
            {"id": str(uuid.uuid4()), "text": "Map operational strategy for soccer org as a family income stream", "category": "money", "badge": "Plan", "done": False, "created": datetime.now().isoformat()},
            {"id": str(uuid.uuid4()), "text": "Continue drafting daycare website on Canva for mom", "category": "money", "badge": "Project", "done": False, "created": datetime.now().isoformat()},
            {"id": str(uuid.uuid4()), "text": "Explore social media content monetization streams", "category": "money", "badge": "Explore", "done": False, "created": datetime.now().isoformat()},
        ],
        "braindumps": []
    }

@app.route("/")
def index():
    return render_template("index.html")

@app.route("/api/tasks", methods=["GET"])
def get_tasks():
    data = load_data()
    return jsonify(data["tasks"])

@app.route("/api/tasks", methods=["POST"])
def add_task():
    data = load_data()
    task = request.json
    task["id"] = str(uuid.uuid4())
    task["done"] = False
    task["created"] = datetime.now().isoformat()
    data["tasks"].append(task)
    save_data(data)
    return jsonify(task), 201

@app.route("/api/tasks/<task_id>", methods=["PUT"])
def update_task(task_id):
    data = load_data()
    for i, t in enumerate(data["tasks"]):
        if t["id"] == task_id:
            data["tasks"][i].update(request.json)
            save_data(data)
            return jsonify(data["tasks"][i])
    return jsonify({"error": "Not found"}), 404

@app.route("/api/tasks/<task_id>", methods=["DELETE"])
def delete_task(task_id):
    data = load_data()
    data["tasks"] = [t for t in data["tasks"] if t["id"] != task_id]
    save_data(data)
    return jsonify({"ok": True})

@app.route("/api/braindump", methods=["POST"])
def braindump():
    body = request.json
    text = body.get("text", "")
    if not text.strip():
        return jsonify({"error": "Empty input"}), 400

    client = anthropic.Anthropic(api_key=ANTHROPIC_API_KEY)

    system = """You are a personal life organization AI assistant. The user will give you a brain dump of thoughts, tasks, worries, or ideas.

Your job is to:
1. Parse the brain dump into individual actionable tasks
2. Suggest the best category for each task from: urgent, health, kids, home, money, routines
3. Suggest a badge from: Today, ASAP, This week, Soon, Ongoing, Daily, Plan, Research, Project, Weekly, Bi-weekly, Priority, Save, Now, Explore
4. Return ONLY valid JSON — no markdown, no explanation, no preamble.

Return this exact JSON structure:
{
  "summary": "A warm, encouraging 1-2 sentence summary of what you heard",
  "tasks": [
    {"text": "task description", "category": "category", "badge": "badge"}
  ]
}"""

    resp = client.messages.create(
        model="claude-sonnet-4-6",
        max_tokens=1500,
        system=system,
        messages=[{"role": "user", "content": text}]
    )

    raw = resp.content[0].text.strip()
    raw = raw.replace("```json", "").replace("```", "").strip()
    result = json.loads(raw)
    return jsonify(result)

@app.route("/api/chat", methods=["POST"])
def chat():
    body = request.json
    message = body.get("message", "")
    history = body.get("history", [])
    data = load_data()
    tasks_context = json.dumps(data["tasks"][:30], indent=2)

    client = anthropic.Anthropic(api_key=ANTHROPIC_API_KEY)

    system = f"""You are a warm, encouraging personal life coach and organization assistant built into the user's LifeOS dashboard. 
You know everything about their life goals, tasks, and situation from their task list.

Current tasks (sample):
{tasks_context}

You know about:
- Her children: Dean (10), Matthew (7), Ava (5)
- Partner: Oskar (works in logistics)
- Goals: lose 15 lbs, 75 hard challenge, credit repair, find $80k+ job, complete MBA
- Active projects: kids' summer schedule, Oskar's youth soccer nonprofit, mom's daycare website

Be warm, concise, actionable, and supportive. Never preachy. Address her directly."""

    messages = history + [{"role": "user", "content": message}]
    resp = client.messages.create(
        model="claude-sonnet-4-6",
        max_tokens=600,
        system=system,
        messages=messages
    )
    return jsonify({"reply": resp.content[0].text})

if __name__ == "__main__":
    app.run(debug=True, port=5000)
