// LifeOS — App Logic

const API = '';
let allTasks = [];
let editingTaskId = null;
let pendingDumpTasks = [];
let chatHistory = [];
let recognition = null;
let activeVoiceTarget = null;

const CATEGORIES = ['urgent','health','kids','home','money'];
const BADGE_CLASS_MAP = {
  'Today':'Today','ASAP':'ASAP','Now':'Now','Priority':'Priority',
  'This week':'This-week','Soon':'Soon','Save for':'Save-for',
  'Ongoing':'Ongoing','Daily':'Daily','Weekly':'Weekly','Bi-weekly':'Bi-weekly',
  'Plan':'Plan','Research':'Research','Project':'Project','Explore':'Explore','Save':'Save'
};

// ── Init ──────────────────────────────────────────────
document.addEventListener('DOMContentLoaded', () => {
  loadTasks();
  initNav();
  initModals();
  initVoice();
  initChallenge();
});

// ── Navigation ────────────────────────────────────────
function initNav() {
  document.querySelectorAll('.nav-item').forEach(btn => {
    btn.addEventListener('click', () => {
      const tab = btn.dataset.tab;
      document.querySelectorAll('.nav-item').forEach(b => b.classList.remove('active'));
      document.querySelectorAll('.panel').forEach(p => p.classList.remove('active'));
      btn.classList.add('active');
      document.getElementById('panel-' + tab).classList.add('active');
      if (window.innerWidth <= 900) closeSidebar();
    });
  });

  const hamburger = document.getElementById('hamburger');
  const overlay = document.getElementById('sidebarOverlay');
  const sidebar = document.getElementById('sidebar');

  hamburger.addEventListener('click', () => {
    sidebar.classList.toggle('open');
    overlay.classList.toggle('open');
  });

  overlay.addEventListener('click', closeSidebar);
}

function closeSidebar() {
  document.getElementById('sidebar').classList.remove('open');
  document.getElementById('sidebarOverlay').classList.remove('open');
}

// ── Tasks ─────────────────────────────────────────────
async function loadTasks() {
  try {
    const res = await fetch(API + '/api/tasks');
    allTasks = await res.json();
    renderAll();
  } catch(e) {
    console.error('Load error', e);
  }
}

function renderAll() {
  CATEGORIES.forEach(cat => renderCategory(cat));
  updateStats();
}

function renderCategory(cat) {
  const container = document.getElementById('tasks-' + cat);
  if (!container) return;
  const tasks = allTasks.filter(t => t.category === cat);
  container.innerHTML = tasks.length
    ? tasks.map(renderTask).join('')
    : '<div style="padding:24px;text-align:center;color:#aaa;font-size:13px">No tasks yet — add one above ✦</div>';

  container.querySelectorAll('.task-check').forEach(el => {
    el.addEventListener('click', e => {
      e.stopPropagation();
      toggleTask(el.closest('.task-item').dataset.id);
    });
  });
  container.querySelectorAll('.task-text').forEach(el => {
    el.addEventListener('click', e => {
      e.stopPropagation();
      toggleTask(el.closest('.task-item').dataset.id);
    });
  });
  container.querySelectorAll('.edit').forEach(el => {
    el.addEventListener('click', e => {
      e.stopPropagation();
      openEditTask(el.closest('.task-item').dataset.id);
    });
  });
  container.querySelectorAll('.delete').forEach(el => {
    el.addEventListener('click', e => {
      e.stopPropagation();
      deleteTask(el.closest('.task-item').dataset.id);
    });
  });
}

function renderTask(t) {
  const badgeKey = BADGE_CLASS_MAP[t.badge] || 'Soon';
  return `
    <div class="task-item ${t.done ? 'done' : ''}" data-id="${t.id}">
      <div class="task-check">
        <span class="task-check-mark">✓</span>
      </div>
      <div class="task-text">${escHtml(t.text)}</div>
      <span class="badge badge-${badgeKey}">${t.badge || 'Soon'}</span>
      <div class="task-actions">
        <button class="task-action-btn edit" title="Edit">✎</button>
        <button class="task-action-btn delete" title="Delete">✕</button>
      </div>
    </div>`;
}

async function toggleTask(id) {
  const task = allTasks.find(t => t.id === id);
  if (!task) return;
  task.done = !task.done;
  try {
    await fetch(API + '/api/tasks/' + id, {
      method: 'PUT',
      headers: {'Content-Type':'application/json'},
      body: JSON.stringify({done: task.done})
    });
    renderAll();
  } catch(e) {}
}

async function deleteTask(id) {
  if (!confirm('Remove this task?')) return;
  try {
    await fetch(API + '/api/tasks/' + id, { method: 'DELETE' });
    allTasks = allTasks.filter(t => t.id !== id);
    renderAll();
  } catch(e) {}
}

function updateStats() {
  const total = allTasks.length;
  const done = allTasks.filter(t => t.done).length;
  const pending = total - done;
  const urgent = allTasks.filter(t =>
    t.category === 'urgent' && !t.done &&
    ['Today','ASAP','Now','Priority'].includes(t.badge)
  ).length;
  document.getElementById('total-count').textContent = total;
  document.getElementById('done-count').textContent = done;
  document.getElementById('pending-count').textContent = pending;
  document.getElementById('urgent-count').textContent = urgent;
  const navBadge = document.getElementById('nav-urgent-count');
  if (navBadge) navBadge.textContent = urgent;
}

// ── Add / Edit Task ───────────────────────────────────
function initModals() {
  // Add task buttons
  document.querySelectorAll('.add-task-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      editingTaskId = null;
      document.getElementById('taskModalTitle').textContent = 'Add Task';
      document.getElementById('taskText').value = '';
      document.getElementById('taskCategory').value = btn.dataset.category;
      document.getElementById('taskBadge').value = 'Soon';
      openModal('taskModal');
    });
  });

  document.getElementById('closeTaskModal').addEventListener('click', () => closeModal('taskModal'));
  document.getElementById('cancelTaskModal').addEventListener('click', () => closeModal('taskModal'));
  document.getElementById('saveTask').addEventListener('click', saveTask);

  // Brain dump
  document.getElementById('openBrainDump').addEventListener('click', () => openDump());
  document.getElementById('mobileOpenBrainDump').addEventListener('click', () => openDump());
  document.getElementById('closeBrainDump').addEventListener('click', () => closeModal('brainDumpModal'));
  document.getElementById('cancelDump').addEventListener('click', () => closeModal('brainDumpModal'));
  document.getElementById('submitDump').addEventListener('click', submitDump);
  document.getElementById('cancelAddAll').addEventListener('click', resetDumpForm);
  document.getElementById('confirmAddAll').addEventListener('click', confirmAddAllTasks);

  // Chat
  document.getElementById('openChat').addEventListener('click', () => openModal('chatModal'));
  document.getElementById('closeChat').addEventListener('click', () => closeModal('chatModal'));
  document.getElementById('sendChat').addEventListener('click', sendChat);
  document.getElementById('chatInput').addEventListener('keydown', e => {
    if (e.key === 'Enter') sendChat();
  });

  document.getElementById('chatVoiceBtn').addEventListener('click', () => {
    startVoice('chatInput', document.getElementById('chatVoiceBtn'));
  });
}

function openDump() {
  document.getElementById('dumpText').value = '';
  document.getElementById('dumpResults').style.display = 'none';
  document.getElementById('dumpLoading').style.display = 'none';
  document.getElementById('submitDump').style.display = 'inline-flex';
  document.getElementById('cancelDump').style.display = 'inline-flex';
  openModal('brainDumpModal');
}

function openEditTask(id) {
  const task = allTasks.find(t => t.id === id);
  if (!task) return;
  editingTaskId = id;
  document.getElementById('taskModalTitle').textContent = 'Edit Task';
  document.getElementById('taskText').value = task.text;
  document.getElementById('taskCategory').value = task.category;
  document.getElementById('taskBadge').value = task.badge;
  openModal('taskModal');
}

async function saveTask() {
  const text = document.getElementById('taskText').value.trim();
  const category = document.getElementById('taskCategory').value;
  const badge = document.getElementById('taskBadge').value;
  if (!text) return alert('Please enter a task description.');

  if (editingTaskId) {
    try {
      const res = await fetch(API + '/api/tasks/' + editingTaskId, {
        method: 'PUT',
        headers: {'Content-Type':'application/json'},
        body: JSON.stringify({text, category, badge})
      });
      const updated = await res.json();
      const idx = allTasks.findIndex(t => t.id === editingTaskId);
      if (idx >= 0) allTasks[idx] = updated;
      renderAll();
      closeModal('taskModal');
    } catch(e) {}
  } else {
    try {
      const res = await fetch(API + '/api/tasks', {
        method: 'POST',
        headers: {'Content-Type':'application/json'},
        body: JSON.stringify({text, category, badge})
      });
      const newTask = await res.json();
      allTasks.push(newTask);
      renderAll();
      closeModal('taskModal');
    } catch(e) {}
  }
}

// ── Brain Dump ────────────────────────────────────────
async function submitDump() {
  const text = document.getElementById('dumpText').value.trim();
  if (!text) return;

  document.getElementById('dumpLoading').style.display = 'flex';
  document.getElementById('submitDump').style.display = 'none';
  document.getElementById('cancelDump').style.display = 'none';

  try {
    const res = await fetch(API + '/api/braindump', {
      method: 'POST',
      headers: {'Content-Type':'application/json'},
      body: JSON.stringify({text})
    });
    const data = await res.json();
    pendingDumpTasks = data.tasks || [];

    document.getElementById('dumpLoading').style.display = 'none';
    document.getElementById('dumpSummary').textContent = data.summary || '';
    renderDumpTasks(pendingDumpTasks);
    document.getElementById('dumpResults').style.display = 'block';
  } catch(e) {
    document.getElementById('dumpLoading').style.display = 'none';
    document.getElementById('cancelDump').style.display = 'inline-flex';
    document.getElementById('submitDump').style.display = 'inline-flex';
    alert('Something went wrong. Please try again.');
  }
}

function renderDumpTasks(tasks) {
  const list = document.getElementById('dumpTasksList');
  list.innerHTML = tasks.map((t, i) => {
    const badgeKey = BADGE_CLASS_MAP[t.badge] || 'Soon';
    return `<div class="dump-task-item" data-index="${i}">
      <div class="dump-task-text">${escHtml(t.text)}</div>
      <div class="dump-task-meta">
        <span class="badge badge-${badgeKey}">${t.badge}</span>
        <span class="badge badge-Plan" style="font-size:10px;padding:2px 8px;">${t.category}</span>
        <button class="dump-remove" onclick="removeDumpTask(${i})">✕</button>
      </div>
    </div>`;
  }).join('');
}

function removeDumpTask(index) {
  pendingDumpTasks.splice(index, 1);
  renderDumpTasks(pendingDumpTasks);
}

async function confirmAddAllTasks() {
  for (const t of pendingDumpTasks) {
    try {
      const res = await fetch(API + '/api/tasks', {
        method: 'POST',
        headers: {'Content-Type':'application/json'},
        body: JSON.stringify({text: t.text, category: t.category, badge: t.badge})
      });
      const newTask = await res.json();
      allTasks.push(newTask);
    } catch(e) {}
  }
  renderAll();
  closeModal('brainDumpModal');
}

function resetDumpForm() {
  document.getElementById('dumpResults').style.display = 'none';
  document.getElementById('submitDump').style.display = 'inline-flex';
  document.getElementById('cancelDump').style.display = 'inline-flex';
}

// ── Chat ──────────────────────────────────────────────
async function sendChat() {
  const input = document.getElementById('chatInput');
  const message = input.value.trim();
  if (!message) return;
  input.value = '';

  appendChatMsg(message, 'user');
  chatHistory.push({role:'user', content: message});

  const typing = appendChatMsg('...', 'ai');

  try {
    const res = await fetch(API + '/api/chat', {
      method: 'POST',
      headers: {'Content-Type':'application/json'},
      body: JSON.stringify({message, history: chatHistory.slice(-8)})
    });
    const data = await res.json();
    typing.textContent = data.reply;
    chatHistory.push({role:'assistant', content: data.reply});
  } catch(e) {
    typing.textContent = 'Sorry, I had trouble connecting. Please try again.';
  }
}

function appendChatMsg(text, role) {
  const msgs = document.getElementById('chatMessages');
  const div = document.createElement('div');
  div.className = 'chat-msg ' + role;
  div.textContent = text;
  msgs.appendChild(div);
  msgs.scrollTop = msgs.scrollHeight;
  return div;
}

// ── Voice Recognition ─────────────────────────────────
function initVoice() {
  if (!('webkitSpeechRecognition' in window) && !('SpeechRecognition' in window)) {
    document.querySelectorAll('.voice-btn').forEach(b => { b.style.opacity = '0.4'; b.title = 'Voice not supported in this browser'; });
    return;
  }

  const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
  recognition = new SpeechRecognition();
  recognition.continuous = false;
  recognition.interimResults = false;
  recognition.lang = 'en-US';

  recognition.onresult = e => {
    const transcript = e.results[0][0].transcript;
    if (activeVoiceTarget) {
      const el = document.getElementById(activeVoiceTarget);
      if (el) el.value = (el.value ? el.value + ' ' : '') + transcript;
    }
    document.getElementById('voiceStatus') && (document.getElementById('voiceStatus').textContent = 'Got it! Edit if needed, then Analyze ✦');
    stopVoiceUI();
  };

  recognition.onerror = () => stopVoiceUI();
  recognition.onend = () => stopVoiceUI();

  document.getElementById('voiceBtn').addEventListener('click', () => {
    startVoice('dumpText', document.getElementById('voiceBtn'));
  });
}

function startVoice(targetId, btn) {
  if (!recognition) return;
  activeVoiceTarget = targetId;
  recognition.start();
  btn.classList.add('recording');
  if (document.getElementById('voiceStatus'))
    document.getElementById('voiceStatus').textContent = '🔴 Listening... speak now';
}

function stopVoiceUI() {
  document.querySelectorAll('.voice-btn').forEach(b => b.classList.remove('recording'));
}

// ── 75 Challenge ──────────────────────────────────────
function initChallenge() {
  const saved = JSON.parse(localStorage.getItem('challenge75') || '{}');

  document.querySelectorAll('.challenge-row').forEach(row => {
    const key = row.dataset.key;
    const cb = row.querySelector('.cb');
    if (saved[key]) { cb.textContent = '●'; cb.classList.add('done'); }

    row.addEventListener('click', () => {
      const isDone = cb.classList.contains('done');
      cb.textContent = isDone ? '○' : '●';
      cb.classList.toggle('done');
      saved[key] = !isDone;
      localStorage.setItem('challenge75', JSON.stringify(saved));
      updateChallengeBar(saved);
    });
  });

  updateChallengeBar(saved);
}

function updateChallengeBar(saved) {
  const keys = ['c1','c2','c3','c4','c5','c6'];
  const done = keys.filter(k => saved[k]).length;
  const pct = Math.round((done / 6) * 100);
  document.getElementById('cbar').style.width = pct + '%';
  document.getElementById('cpct').textContent = pct + '%';
}

// ── Modal helpers ─────────────────────────────────────
function openModal(id) { document.getElementById(id).classList.add('open'); }
function closeModal(id) { document.getElementById(id).classList.remove('open'); }

document.addEventListener('click', e => {
  if (e.target.classList.contains('modal-overlay')) {
    e.target.classList.remove('open');
  }
});

// ── Utils ─────────────────────────────────────────────
function escHtml(str) {
  return String(str).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
}
